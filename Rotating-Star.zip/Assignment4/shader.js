/*
  File: shader.js
  Name: Chaudhry Sadiq
  Description: Shader Art for an orbiting star the star orbits around the mouse.
  Date: 25/02/2025
*/

// Vertex Shader Source Code
const vertexShaderSource = `#version 300 es
   in vec4 a_position;
   void main() {
      gl_Position = a_position;
   }
`;

// Fragment Shader Source Code
const fragmentShaderSource = `#version 300 es
   precision highp float;
   out vec4 outColor;
   uniform vec2 u_resolution;
   uniform vec2 u_mouse;
   uniform float u_time;

   void main() {
      vec2 uv = gl_FragCoord.xy / u_resolution;
      vec2 mouse = u_mouse / u_resolution;

      // Shooting star position and trail
      float starSpeed = 0.5;
      vec2 starPos = vec2(mouse.x + sin(u_time * starSpeed) * 0.2, mouse.y + cos(u_time * starSpeed) * 0.2);
      float star = smoothstep(0.01, 0.005, distance(uv, starPos));

      // Adding a glowing effect
      float glow = 0.02 / distance(uv, starPos);
      outColor = vec4(star + glow, star + glow, star + glow, 1.0);
   }
`;

// Initializing WebGL2 Context
function initWebGL() {
   const canvas = document.getElementById("webgl-canvas");
   const gl = canvas.getContext("webgl2");
   if (!gl) {
      console.error("WebGL2 is not supported in your browser.");
      return null;
   }
   return gl;
}

// Compiling Shader
function compileShader(gl, source, type) {
   const shader = gl.createShader(type);
   gl.shaderSource(shader, source);
   gl.compileShader(shader);
   if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
      console.error("Shader compilation failed:", gl.getShaderInfoLog(shader));
      gl.deleteShader(shader);
      return null;
   }
   return shader;
}

// Creating Shader Program
function createShaderProgram(gl, vertexShader, fragmentShader) {
   const program = gl.createProgram();
   gl.attachShader(program, vertexShader);
   gl.attachShader(program, fragmentShader);
   gl.linkProgram(program);
   if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
      console.error("Shader program linking failed:", gl.getProgramInfoLog(program));
      return null;
   }
   return program;
}

// Setting Up Buffers
function setupBuffers(gl) {
   const positionBuffer = gl.createBuffer();
   gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);
   const positions = [
      -1, -1,
       1, -1,
      -1,  1,
       1,  1,
   ];
   gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(positions), gl.STATIC_DRAW);
   return positionBuffer;
}

// Resizing Canvas to Full Screen
function resizeCanvasToDisplaySize(canvas) {
   const displayWidth = window.innerWidth;
   const displayHeight = window.innerHeight;

   if (canvas.width !== displayWidth || canvas.height !== displayHeight) {
      canvas.width = displayWidth;
      canvas.height = displayHeight;
   }
}

// Rendering Loop
function render(gl, program, positionBuffer) {
   const resolutionUniformLocation = gl.getUniformLocation(program, "u_resolution");
   const mouseUniformLocation = gl.getUniformLocation(program, "u_mouse");
   const timeUniformLocation = gl.getUniformLocation(program, "u_time");

   let mouseX = 0, mouseY = 0;
   document.addEventListener("mousemove", (event) => {
      mouseX = event.clientX;
      mouseY = event.clientY;
   });

   function draw() {
      resizeCanvasToDisplaySize(gl.canvas); 
      gl.viewport(0, 0, gl.canvas.width, gl.canvas.height);
      gl.clearColor(0, 0, 0, 1);
      gl.clear(gl.COLOR_BUFFER_BIT);

      gl.useProgram(program);
      gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);
      const positionAttributeLocation = gl.getAttribLocation(program, "a_position");
      gl.enableVertexAttribArray(positionAttributeLocation);
      gl.vertexAttribPointer(positionAttributeLocation, 2, gl.FLOAT, false, 0, 0);

      gl.uniform2f(resolutionUniformLocation, gl.canvas.width, gl.canvas.height);
      gl.uniform2f(mouseUniformLocation, mouseX, gl.canvas.height - mouseY);
      gl.uniform1f(timeUniformLocation, performance.now() / 1000);

      gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
      requestAnimationFrame(draw);
   }
   draw();
}

// Main Function
function main() {
   const gl = initWebGL();
   if (!gl) return;

   const vertexShader = compileShader(gl, vertexShaderSource, gl.VERTEX_SHADER);
   const fragmentShader = compileShader(gl, fragmentShaderSource, gl.FRAGMENT_SHADER);
   const program = createShaderProgram(gl, vertexShader, fragmentShader);
   const positionBuffer = setupBuffers(gl);

   // Handling window resizing
   window.addEventListener("resize", () => {
      resizeCanvasToDisplaySize(gl.canvas);
   });

   render(gl, program, positionBuffer);
}

main();